import xbmc

xbmc.executebuiltin('RunScript(resources.iptv.com.bulsat, False)')
