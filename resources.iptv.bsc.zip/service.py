import xbmc

xbmc.executebuiltin('RunScript(resources.iptv.bsc, False)')
