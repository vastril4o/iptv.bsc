# resources.iptv.com.bulsat
Addon for bulsatcom, this addon will generate .m3u and .xml files for channel stream and epg data.

* You need user registration in [www.bulsat.com](http://www.bulsat.com).

* You need [IPTV Simple Client - win](http://kodi.wiki/view/Add-on:IPTV_Simple_Client) / [IPTV Simple Client - ubuntu](http://kodi.wiki/view/Ubuntu_PVR_add-ons) to watch iptv and to have epg for channels.
